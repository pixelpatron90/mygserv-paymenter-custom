<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Linhas de idioma de paginação
    |--------------------------------------------------------------------------
    |
    | As seguintes linhas de paginação são usadas para os links de paginação.
    | Você é livre para alterá-las como desejar.
    | Se você tiver uma ideia mais emocionante, nos informe.
    |
    */

    'previous' => '&laquo; Anterior',
    'next'     => 'Seguinte &raquo;',

];
