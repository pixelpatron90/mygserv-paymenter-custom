<?php

namespace App\Classes\Extensions;

class Event extends Extension
{
    //
}
